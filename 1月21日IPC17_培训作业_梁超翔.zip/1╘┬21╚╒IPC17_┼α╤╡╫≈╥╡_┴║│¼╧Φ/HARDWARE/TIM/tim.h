#ifndef _TIM_H
#define _TIM_H

#include "sys.h"

void second_clock_increase(void);
void minute_clock_increase(void);
void hour_clock_increase(void);
void set_clock_flag(void);
void clock_display(void);
void clock_init(void);
void TIM3_Init(u16 arr,u16 psr);               //arr:��ת��ֵ  psc:Ԥ��Ƶϵ��

#define clock_start   TIM_Cmd(TIM3,ENABLE)     //������ʱ
#define clock_stop    TIM_Cmd(TIM3,DISABLE)    //��ͣ��ʱ

#endif

