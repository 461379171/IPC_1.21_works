#include "tim.h"
#include "sys.h"
#include "led.h"
#include "bee.h"
#include "stm32f4xx.h"
#include "IIC1.h"
#include "OLED.h"


/**********
��ʱ��TIM3��ʼ��
**********/
void TIM3_Init(uint16_t arr,uint16_t psc)
{   
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	NVIC_InitTypeDef NVIC_InitStructure;

	TIM_TimeBaseInitStruct.TIM_Period = arr-1;
	TIM_TimeBaseInitStruct.TIM_Prescaler = psc-1;
	TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0x00;
	TIM_TimeBaseInit(TIM3,&TIM_TimeBaseInitStruct);
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);         //�������ȼ�����ռ���ȼ�
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;         //����Interupt ReQuest���ж�Ҫ��
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE);
}


int TimeFlag=0;
int SecondTime=0;
int MinuteTime=0;
int HourTime=0;

/**********
��ʱ�����ñ�־λ��
ÿ��һ�ζ�ʱ���жϣ�TimeFlag ��1
**********/
void set_clock_flag(void)
{
	TimeFlag=1;
}


/**********
ʱ����ʾ��ʼ����
0 0 0
**********/
void clock_init(void)
{
	OLED_ShowNum(2,8,00,2);
	OLED_ShowNum(3,8,00,2);
	OLED_ShowNum(4,8,00,2);
}


/**********
OLEDʱ����ʾ
**********/
void clock_display(void)
{
	OLED_ShowString(1,6,"CLOCK");
	OLED_ShowString(2,1,"Second:");
	OLED_ShowString(3,1,"Minute:");
	OLED_ShowString(4,1,"Hour:  ");
	second_clock_increase();
	minute_clock_increase();
	hour_clock_increase();
}


/**********
��������
**********/
void second_clock_increase(void)
{
	if(TimeFlag==1)
	{
		OLED_ShowNum(2,8,SecondTime,2);
		SecondTime++;
		TimeFlag=0;
	}
}


/**********
��������
**********/
void minute_clock_increase(void)
{
	if(SecondTime>60)
	{
		SecondTime=1;
		MinuteTime++;
		OLED_ShowNum(3,8,MinuteTime,2);
	}
}


/**********
Сʱ����
**********/
void hour_clock_increase(void)
{
	if(MinuteTime>60)
	{
		MinuteTime=1;
		HourTime++;
		OLED_ShowNum(4,8,HourTime,2);
		if(HourTime>24)
			HourTime=0;
	}
}


/**********
��ʱ��TIM3�жϷ�����
**********/
void TIM3_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM3,TIM_IT_Update)==SET) //����ж�
	{
		set_clock_flag();
	}
	TIM_ClearITPendingBit(TIM3,TIM_IT_Update);  //����жϱ�־λ
}



