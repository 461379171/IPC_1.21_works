#ifndef __EXTI_H_
#define __EXTI_H_

#include "stm32f4xx.h"
#include "delay.h"
void exti_init(void);
void sing_doub_long_click_led_bee();
#define KeyLevel1   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_3)
#define KeyLevel2   GPIO_ReadInputDataBit(GPIOD,GPIO_Pin_4)

#endif 

