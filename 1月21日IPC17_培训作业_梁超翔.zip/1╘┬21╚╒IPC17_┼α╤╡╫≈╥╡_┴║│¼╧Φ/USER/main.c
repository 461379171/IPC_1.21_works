#include "stm32f4xx.h"
#include "delay.h"
#include "tim.h"
#include "IIC1.h"
#include "OLED.h"
#include "exti.h"
int main(void)
{

  delay_init(168);
  exti_init();
  OLED_I2C_Init();
  OLED_Init();
  clock_init();
  TIM3_Init(10000,12600); 	
  while(1)
    {
        clock_display();
	}
}



